import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * Class that represents Startpoint to all Clients. 
 * Incoming TCP connections get accepted and forwarded to own thread here.
 *
 */
public class Lobby {

	/*
	 * The global DNChat Object
	 */
	public static DNChat dnChat;
	
	/**
	 * Creates a global DNChat Object and assigns it to the static field dnChat,
	 * afterwards waits for incoming TCP-Connections.
	 * If a connection comes in a new thread is created.
	 * The main thread is active all the time. 
	 * @param args - No Arguments Expected
	 */
	public static void main(String[] args) {
		dnChat = new DNChat();
		try {
			ServerSocket socket = new ServerSocket(42015);
			while(true){
				Socket connection=socket.accept();
				DataInputStream in=new DataInputStream(connection.getInputStream());
				DataOutputStream out=new DataOutputStream(connection.getOutputStream());
				new ClientThread(out, in, connection).start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
